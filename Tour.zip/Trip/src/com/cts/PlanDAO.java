package com.cts;



public interface PlanDAO {
	public int add(Plan p);
	public Plan getPlanDisplay(String username);
}
