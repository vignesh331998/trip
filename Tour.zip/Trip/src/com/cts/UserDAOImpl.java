package com.cts;
import java.sql.*;
public class UserDAOImpl implements UserDAO {

	static Connection conn;
	static PreparedStatement ps;
	@Override
	public int insertUser(User u) {
		// TODO Auto-generated method stub
		int status=0;
		try {
			conn=DBConnection.getConn();
			  ps = conn.prepareStatement("insert into detail values(?,?,?)");
		         
	            ps.setString(1,u.getUsername());
	            ps.setString(2, u.getName());
	             ps.setString(3,u.getPassword());          
	            status= ps.executeUpdate();
	            conn.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return status;
	}

	@Override
	public User getUser(String username, String password) {
		// TODO Auto-generated method stub
		User u=new User();
try {
			conn=DBConnection.getConn();
			ps=conn.prepareStatement("select * from detail where username=? and password=?");
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				u.setUsername(rs.getString(1));
				u.setName(rs.getString(2));
				u.setPassword(rs.getString(3));
			}
				}catch(Exception e)
		{
			System.out.println(e);
		}
		return u;
	}

}
