package com.cts;
import java.sql.*;

public class DBConnection implements Myprovider {

	static Connection conn=null;
	
	public static Connection getConn()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection(url,username,password);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return conn;
		
	}
	
}
