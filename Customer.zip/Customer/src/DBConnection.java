

import java.sql.Connection;
import java.sql.DriverManager;



public class DBConnection {
	


	static Connection con=null;
	
	public static Connection getConnection()
	{
		try {
			Class.forName("com.mysql.jdbc.driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:1521/xe", "root", "root");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;
		
	}
	
}

//jdbc:oracle:thin:@//localhost:1521/xe