
public interface CustomerDAO {

	public int insertCustomer(Customer c);
	public  Customer getCustomer(String name,String age);
}
