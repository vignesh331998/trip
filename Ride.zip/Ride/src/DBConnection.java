import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
	static Connection con;
	public static Connection getCon()
	{
		try {
			Class.forName("");
			con=DriverManager.getConnection("");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;
		
	}
}
