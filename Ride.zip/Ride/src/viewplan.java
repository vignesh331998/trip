

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class viewplan
 */
@WebServlet("/viewplan")
public class viewplan extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public viewplan() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection con=DBConnection.getCon();
		PrintWriter out=response.getWriter();
        try {
        	String sql="select * from plan";
        	PreparedStatement ps=con.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            String str="<table><tr><th>Location</th><th>Startdate</th><th>Enddate</th>";
            while(rs.next())
            {
            	str +="<tr><td>"+rs.getString(1)+"<tr><td>"+rs.getString(2)+"<tr><td>"+rs.getString(3);
            }
            str +="</table>";
            out.println(str);
            con.close();
        }catch(Exception e)
        {
        	System.out.println(e);
        }
        finally {
        	out.close();
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

}
