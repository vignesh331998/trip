package com.cts;



public interface Myprovider {
String username="";
String password="";
String url="";

}
