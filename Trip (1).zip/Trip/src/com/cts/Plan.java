package com.cts;

public class Plan {
	String location;
	String startdate;
	String enddate;

	public Plan() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Plan(String location, String startdate,String enddate) {
		super();
		this.location = location;
		this.startdate = startdate;
	        this.enddate = enddate;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getStartdate() {
		return startdate;
	}

	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}


	public String getEnddate() {
		return enddate;
	}

	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}

	@Override
	public String toString() {
		return "Plan [location=" + location + ", startdate=" + startdate + ", enddate=" + enddate + "]";
	}
}
