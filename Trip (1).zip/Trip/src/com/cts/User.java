package com.cts;

public class User {
	
		String username;
		String password;
		
		public String getUserName() {
			return username;
		}
		public void setUserName(String username) {
			this.username = username;
		}
		
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		
		public User(String username,String password) {
			super();
			this.username = username;
			this.password = password;
			
		}
		public User() {
			super();
			// TODO Auto-generated constructor stub
		}
		@Override
		public String toString() {
			return "UserTable [username=" + username + ",password=" + password + "]";
		}
}
