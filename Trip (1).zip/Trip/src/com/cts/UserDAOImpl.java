package com.cts;
import java.sql.*;
public class UserDAOImpl implements UserDAO {

	static Connection conn;
	static PreparedStatement ps;
	@Override
	public int insertUser(User u) {
		// TODO Auto-generated method stub
		int i=0;
		try {
			conn=DBConnection.getConn();
			  ps = conn.prepareStatement("insert into user(username,password) values(?,?)");
		         
	            ps.setString(1,u.getUserName());
	            ps.setString(2, u.getPassword());
	                       
	            i = ps.executeUpdate();
	            conn.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return i ;
	}

	@Override
	public User getUser(String username, String password) {
		// TODO Auto-generated method stub
		User u=new User();
try {
			conn=DBConnection.getConn();
			ps=conn.prepareStatement("select * from user where username=? and password=?");
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				u.setUserName(rs.getString(1));
				u.setPassword(rs.getString(2));
			}
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return u;
	}

}
