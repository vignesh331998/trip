package com.cts;

import java.sql.*;


public class PlanDAOImpl implements PlanDAO {
	static Connection conn;
	static PreparedStatement ps;
	@Override
	public int add(Plan p) {
		// TODO Auto-generated method stub
		int i=0;
		try {
			conn=DBConnection.getConn();
			  ps = conn.prepareStatement("insert into plan(location,startdate,enddate) values(?,?,?)");
		         
	            ps.setString(1,p.getLocation());
	            ps.setString(2, p.getStartdate());
	            ps.setString(2, p.getEnddate());           
	            i = ps.executeUpdate();
	            conn.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return i;
	}

	@Override
	public Plan getPlanDisplay (String location,String startdate,String enddate) {
		// TODO Auto-generated method stub
		Plan p=new Plan();
		try {
					conn=DBConnection.getConn();
					ps=conn.prepareStatement("select * from plan where location=? and startdate=? and enddate=?");
					ps.setString(1, location);
					ps.setString(2, startdate);
					ps.setString(3, enddate);
					ResultSet rs=ps.executeQuery();
					while(rs.next())
					{
						p.setLocation(rs.getString(1));
						p.setStartdate(rs.getString(2));
						p.setEnddate(rs.getString(3));
					}
				}catch(Exception e)
				{
					System.out.println(e);
				}
		return  p;
	}

}
